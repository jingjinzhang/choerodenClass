#!/bin/bash

echo "开始运行"
mvn clean package

echo "Exam1程序运行结果："
java -jar ./Exam1/target/Exam1.jar

echo "Exam2程序运行结果："
java -jar ./Exam2/target/Exam2.jar

echo "Exam3程序运行结果："
java -jar ./Exam3/target/Exam3.jar $1
