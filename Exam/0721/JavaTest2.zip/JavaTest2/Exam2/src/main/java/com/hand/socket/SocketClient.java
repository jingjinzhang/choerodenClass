package com.hand.socket;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;

public class SocketClient extends Thread{

	public static void main(String[] args) {
		Socket socket = new Socket();
		try {
			socket.connect(new InetSocketAddress(12345));
			BufferedInputStream bis = new BufferedInputStream(socket.getInputStream());
			BufferedOutputStream bos = new BufferedOutputStream(
					new FileOutputStream(
							new File("Exam2/temp/SampleChapter1.pdf")));
			byte[] bytes = new byte[1000];
			int count;
			while((count = bis.read(bytes)) != -1){
				bos.write(bytes,0,count);
				System.out.println("---");
			}
			bos.close();
			bis.close();
			System.out.println("读取成功"+count);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
