﻿1.git clone https://github.com/jingjinzhang/JavaTest2.git
2.进入JavaTest2
4.运行build.sh xxx(股票代码)
运行了程序1完成后到程序2由于监听被阻塞，此时重启一个sh run.sh 可以查看到程序2结果
5.运行玩程序2回到最初的gitbach 可以看到程序3结果完成