#!/bin/bash

echo "开始运行socketClient"

java -cp ./Exam2/target/Exam2.jar com.hand.socket.SocketClient
